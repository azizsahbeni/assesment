package edu.isgb.tp1.ex1;

public class ex1 {public static void main(String [] args)
{ int n;
n=Integer.parseInt(args[0]);
for (int i=0; i<n;i++)
System.out.println(" bonjour groupe \"lig3\"");
System.out.println(args[0]);
}
}
