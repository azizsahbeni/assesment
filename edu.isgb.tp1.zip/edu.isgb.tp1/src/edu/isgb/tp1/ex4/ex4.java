package edu.isgb.tp1.ex4;

public class ex4 {
	public static void main(String[] args){ 
		String S;
		int n;
		S=args[0]; 
		n= Integer.parseInt(args[1]); 
		for ( int i=0; i <n;i++)
			System.out.println(S);
		}

}
