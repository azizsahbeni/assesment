package edu.isgb.tp1.ex9;

public class ex9 {
	 public static void main(String[] args) {
	        int x = Integer.parseInt(args[0]);
	        int n = Integer.parseInt(args[1]);

	        long result = 1;
	        for (int i = 0; i < n; i++) {
	            result *= x;
	        }

	        System.out.println(x + " puissance " + n + " = " + result);
	    }
}
