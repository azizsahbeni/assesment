package edu.isgb.tp1.ex2;

public class EX2 {public static void main(String[] args) 
{ 
float moyenne= 10.5f;
System.out.println(25+25); 
System.out.println("25"+25); 
System.out.println("Mohamed"+1);
System.out.println("La moyenne"+"de la classe="+moyenne+2);
}
}
