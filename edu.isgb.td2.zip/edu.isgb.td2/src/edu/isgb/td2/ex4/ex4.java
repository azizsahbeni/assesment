package edu.isgb.td2.ex4;
import java.util.Scanner;
public class ex4 {
    public static void main(String[] args) {

        Scanner clavier = new Scanner(System.in);
        System.out.print("Entrer la premiere valeur : ");
        int x = clavier.nextInt();
        System.out.print("Entrer la deuxieme valeur : ");
        int y = clavier.nextInt();
        int max = Math.max(x, y);

        System.out.println("Le maximum est : " + max);

        clavier.close();
    }


}

	

