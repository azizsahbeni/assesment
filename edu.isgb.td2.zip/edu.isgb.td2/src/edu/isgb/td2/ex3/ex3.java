package edu.isgb.td2.ex3;

public class ex3 {
	public static void main(String[] args) {

      
        int[] tableau = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int somme = 0;
        for (int i = 0; i < tableau.length; i++) {
            somme += tableau[i];
        }

        System.out.println("La somme des elements du tableau = " + somme);
        int temp;
        for (int i = 0; i < tableau.length / 2; i++) {
            temp = tableau[i];
            tableau[i] = tableau[tableau.length - 1 - i];
            tableau[tableau.length - 1 - i] = temp;
        }
        System.out.println("Tableau inverse :");
        for (int i = 0; i < tableau.length; i++) {
            System.out.print(tableau[i] + " ");
            
        }


    }}

	        
	    


