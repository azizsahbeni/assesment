package edu.isgb.td2.ex2;

public class ex2 {
	 public static void main(String[] args) {

	        int x = 5;
	        int y = 3;
	        int z = x++ + y; 
	        int compteur = 12;
	        if (compteur > 10) {
	            System.out.println("> 10");
	        }
	        int total = 20;
	        total -= --x;
	        int q = 17;
	        int diviseur = 5;
	        q = q % diviseur;
	        q %= diviseur;
	        int somme;
	        int x2;
	        x2 = 1;
	        somme = 0;
	        while (x2 < 11) {
	            somme += x2;
	            x2++;
	        }
	        System.out.println("la somme vaut : " + somme);
	    }

}
